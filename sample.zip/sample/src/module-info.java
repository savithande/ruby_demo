module sample {
}